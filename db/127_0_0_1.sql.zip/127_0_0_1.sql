-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2018 at 06:18 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `niazmandi_db`
--
CREATE DATABASE IF NOT EXISTS `niazmandi_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_persian_ci;
USE `niazmandi_db`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_agahi`
--

CREATE TABLE `tbl_agahi` (
  `id` int(11) NOT NULL,
  `user_id` int(255) NOT NULL,
  `onvan` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `tozihat` text COLLATE utf8_persian_ci NOT NULL,
  `price` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `pic` text COLLATE utf8_persian_ci NOT NULL,
  `tarikh` varchar(25) COLLATE utf8_persian_ci NOT NULL,
  `taeed` int(1) NOT NULL DEFAULT '0',
  `city_id` int(255) NOT NULL,
  `mahale_id` int(255) NOT NULL,
  `cat_id` int(255) NOT NULL,
  `visit` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tbl_agahi`
--

INSERT INTO `tbl_agahi` (`id`, `user_id`, `onvan`, `tozihat`, `price`, `pic`, `tarikh`, `taeed`, `city_id`, `mahale_id`, `cat_id`, `visit`) VALUES
(1, 44, 'آپارتمان شیک یک خوابه باهنر', 'سلام .یک آپارتمان یک خوابه دارم طبقه سوم آسانسور دارد تراس دارد پارکینگ داردحمام دستشوی جدا خانه رنگامیزی کاغذ دیواری درب چوبی تمام رنگ شده موکت نو پرده نو کمد دیواری بزرگ دارد تراس بزرگ هم دارد 57 کلید خور 12پارکینگ اختساسی مهوته برای پارکینگ مهمان هم دارد شیک مرتب سند آزاد برای وام 45متری باهنر کوچه شهید مندنی پور کوچه آخر سر نبش آپارتمان دانش نما آجری است.', '85000000', 'e5c19a6180b82b6ae2514fcb1ddb078c.jpeg|1460a0d1b6d6e6ef8d522bfa3e7372c6.jpeg|80e645fd81b16a750ceed63ecce7176e.jpeg|756cb25462d414cd85d4b9f73ca07317.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 3, 20, 7, 2),
(2, 44, 'اپارتمان 130 متری موقعیت اداری', '1خواب ،بصورت اداری ،امکانات،اماده به تحویل', 'توافقی', '884be9d09ec73e07e27847300eeb13fe.jpeg|835162b6c03c8191d71caa50421fe852.jpeg|906a9787870b14768c3e7b3ca2fe69fd.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 10, 3),
(3, 44, 'موتور بنلی 150 مدل95', 'بیمه 10 ماه دارد فنی وبدنه سالم وبه شرط', '5100000', '5626c079c405a392e1122a6b5e7a045d.jpeg|f2f04f0d3b78a0e8783606b8e563aa32.jpeg|29a5888783d216f9427bfaa30f315c8f.jpeg|b08b021c9e783caaad5a363b84a25c64.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 2, 15, 1),
(4, 44, 'کتونی ویتنام سایز ۴۱', 'کتونی ویتنام سایز ۴۱ یکبار پوشیده شده سایز نبود قیمت نصف خرید زدم فروش بره', '100000', '19059b33478bb24cbe56c5fb2d9b79b4.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 2, 20, 1),
(5, 44, 'صندلی ماشین Evenflo', 'برند آمریکایی \r\nتمیز و سالم فقط قسمت پشت آفتاب سوخته شده و رنگش بور شده\r\nگواهینامه استاندارد اروپا و ایمن \r\nمناسب بچه از ۱ سال تا ۴ سال \r\nدارای۳ حالت خوابیده ونشسته', '450000', '04c95265681b6bd66364df13ff751603.jpeg|6b51b3adba5b722d0c08425c39326373.jpeg|ab90f9b6e3de12d253fc5eaa44f65c75.jpeg|c8c36359998f784e9b3e84b498218cc6.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 2, 11, 24, 1),
(6, 44, 'میز مدیریت ماهان گستر', 'تولیدی کننده انواع میزهای مدیریت با قیمت مناسب و کیفیت عالی.\r\nخریدی بی واسطه از تولیدی به قیمت تولید.\r\nفروش به صورت تکی وعمده امکان پذیر می باشد .\r\nآدرس دفتر : خیابان آیت الله کاشانی پشت مسجد نظام مافی کوچه سازمان آب تولیدی ماهان گستر\r\nشماره تماس : ٤٤٠٠٥٩١٤-٤٤٠٠٩٤٢٧\r\n٠٩١٢٥٨٤٨٨٦٩. پاشایی', '500000', '7905934f655a63d08852e7f5bd772564.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 2, 25, 1),
(7, 44, 'میله همزن چسب کارکو', 'تمام استیل،حمل اسان،قابلیت نصب در دریل.ارسال به تمام نقاط کشور.', 'توافقی', '8985aa1913bb8eb7002e1c2615bdc84d.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 3, 25, 1),
(8, 44, 'ترولی رنگ', 'سلام \r\nفاپکو تولید کننده ترولی رنگ \r\nرنگ مشکی, سفید و قرمز \r\nرنگ کوره ای \r\nکشوهای مقاوم \r\nو کیفیت و گارانتی \r\nساعت تماس و مراجعه ۹الی ۱۸\r\nشهرک صنعتی چهاردانگه شهرک صنفی سهند سهند چهارم سوله های سبز قدیم پلاک ۱/۴۲', 'توافقی', '6a3bb9ad006993a0653143e0aff8ade7.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 25, 1),
(9, 44, 'آگهی تست 1', 'توضیحات تست 1', '15000', 'dd2537a1bcab09e46362fc7c7b249899.jpeg|d3491fd487664af30b607023da69cdb5.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 3, 7, 1),
(10, 44, 'آگهی تست 2', 'توضیحات آگهی تست 2', '12000', 'd5e9fe3633b7f12ba6dd20dd05ba76b3.jpeg|0696cef3dfa1faa4cc380469771b6c55.jpeg|d97ae95b8753a35904eebb98ffe22e22.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 5, 12, 1),
(11, 44, 'آگهی تست 3', 'توشحات آگهی تست 3', '39900000', 'c12a50741a71afe59fd5a21f967bceef.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 6, 16, 1),
(12, 44, 'آگهی تست 4', 'توضیحات آگهی تست 4', 'توافقی', 'no', '۱۳۹۷/۰۴/۳۱', 1, 1, 7, 14, 1),
(13, 44, 'آگهی تست 5', 'توضیحات 5', '1000', 'no', '۱۳۹۷/۰۴/۳۱', 1, 1, 8, 21, 1),
(14, 44, 'آگهی تست 6', 'توضیحات ', '30000', '83e60209283865702611780c1f0de75c.jpeg|998b67127d6121017336dfc1f63e51ae.jpeg|d07648815ea2a578989fb47b09af2c62.jpeg|cf08098a1479c1079463fbb19fe56a1e.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 10, 19, 1),
(15, 44, 'آگهی تست 7', 'توضیحات 7', 'توافقی', '6aec97a17065a8c3db3f4c1a1026623f.jpeg|7464c0a4a8a3bdcd443f92f488ae4843.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 9, 11, 1),
(16, 44, 'آگهی تست 8', 'توضیحات 8', 'توافقی', '69742d8a4ee8a0560a993675c50ff023.jpeg|b503464acc96feef2bd2a28e2171b5a4.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 6, 23, 1),
(17, 44, 'آگهی تست 9', 'توضیحات 9', '14000', 'no', '۱۳۹۷/۰۴/۳۱', 1, 1, 5, 13, 2),
(18, 44, 'آگهی تست 10', 'توضیحات آگهی تست 10', '200', '6fb238e970d8b029ff98e2ce9aa4565f.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 3, 9, 1),
(19, 44, 'آگهی تست 11', 'توضیحات 11', '150000', 'c238730454cc19f3999a0b2d2c4349de.jpeg|338e0420f748e05657b9ef0651f0a5ce.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 14, 1),
(20, 44, 'آگهی تست 12', 'توضیحات 12', '140000', 'no', '۱۳۹۷/۰۴/۳۱', 1, 1, 3, 17, 1),
(21, 44, 'آگهی تست:13', 'توضیحات 13', 'توافقی', 'dfdbdab66d0bd052f3bee2110fbf6e64.jpeg|17e31d2aa8ef7c8923641901466bc0e6.jpeg|a00066ad4dd77a903119e3c94df0af48.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 2, 6, 1),
(22, 44, 'آگهی تست: 14', 'توضیحات 14', '32000', 'a132d2b49fa3ec170d661804034c7387.jpeg|4a8dae7f1220231f7941bb5e77eedb4b.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 3, 18, 1),
(23, 44, 'آگهی تست: 15', 'توضیحات 15', 'توافقی', '3640a7560a928e385586a78ff062e9f8.jpeg|650ab1db6fe3b56a83b203d1f92c1cf8.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 8, 7, 1),
(24, 44, 'آگهی تست: 16', 'توضیحات 16', '3000', 'aff4d6a71259f98ce8ecc4c890eafb71.png|3998e978d58fccd04c36be9917aeeeef.png|ed8063804ab8f2464a69735a39988bea.png|0d876d9f6f2c215f54ed635e98e5b869.png', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 7, 1),
(25, 44, 'آگهی تست: 17', 'توضیحات 14', '2500', '217c9c7721ab7453d2eb8020d0ae826a.png|fff2ab315ca20e85f23e18921c14a779.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 8, 10, 2),
(26, 44, 'اگهی تست 17', 'توضیحات 17', '36000', '44d1aa34aac4a2656a141de8d4e0390a.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 7, 6, 1),
(27, 44, 'آگهی تست 20', 'توضیحات آگهی تست 20', '300', '04ec5898ce2990796e2b3d5f81b1aefc.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 2, 6, 1),
(28, 44, 'آگهی تست 21', 'توضیحات آگهی تست 22', 'توافقی', 'no', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 8, 1),
(29, 44, 'آگهی تست 22', 'توضیحات آگهی تست 22', '2300', '2128c8608e9cc0a20820c20e41dd3342.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 26, 1),
(30, 44, 'آگهی تست 23', 'توضیحات آگهی تست 23', 'توافقی', 'no', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 26, 1),
(31, 44, 'آگهی تست 25', 'توضیحات آگهی تست 25', '300', '235f1045474717c1a141643a1e436735.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 5, 12, 1),
(32, 44, 'آگهی تست 27', 'توضیحات آگهی تست 27', '300', 'no', '۱۳۹۷/۰۴/۳۱', 1, 1, 6, 6, 1),
(33, 44, 'آگهی تست 27', 'توضیحات آگهی تست 27', '27000', '8b8e81da7ca551272ffb6eb4d501af1e.jpeg|8a5385b268c8194147d93e41fdfb6974.jpeg|35388a5dc8f483cb540b516b896cc3e4.jpeg|618cac78b38702bd16915a922d9244ca.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 23, 1),
(34, 44, 'آگهی تست  28', 'توضیحات آگهی تست 28', 'توافقی', 'no', '۱۳۹۷/۰۴/۳۱', 1, 1, 8, 11, 1),
(35, 44, 'آگهی تست 29', 'توضیحات آگهی تست 29', '34000', 'ae133c6440764cae5bf455248b52f8d0.jpeg|599cc31007d0975b23965dff1de13f7d.jpeg|0338c89ab1d76f16b14e00ec95ca6d94.jpeg|6a0f0fdda96cb7f45b326a345309a33b.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 6, 7, 1),
(36, 44, 'آگهی تست  29', 'توضیحات آگهی تست 29', '3600', 'no', '۱۳۹۷/۰۴/۳۱', 1, 1, 2, 26, 1),
(37, 44, 'آگهی تست 30', 'توضیحات آگهی تست 30', '6000000000', 'd64dc3fd7afcbe81fecce318a6a4ba58.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 20, 1),
(38, 44, 'آگهی تست 30', 'توضیحات آگهی تست 30', '633', 'eee2106abac0853c1582e4c84a0ad6bb.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 11, 1),
(39, 44, 'آگهی تست 31', 'توضیحات آگهی تست 31', '322', 'dc0214f0e0e0aa4385c446b8a9ddc90b.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 11, 1),
(40, 44, 'آگهی تست 32', 'توضیحات آگهی تست 32', '8563000', 'no', '۱۳۹۷/۰۴/۳۱', 1, 1, 8, 7, 1),
(41, 44, 'آگهی تست 33', 'توضیحات آگهی تست 33', '6500', '090ddc451a1c574c8466a447f2c94567.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 3, 11, 2),
(42, 44, 'آگهی تست 34', 'توضیحات آگهی تست 34', '34000', '2d4da56f44b29493a1c7add6acc761a4.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 2, 11, 12, 1),
(43, 44, 'آگهی تست 35', 'توضیحات آگهی تست 35', 'توافقی', 'de4ce93e455489cf9ce420264b24ff02.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 2, 12, 8, 1),
(44, 44, 'آگهی تست 35', 'توضیحات آگهی تست 35', 'توافقی', '38887386d90a650a9ad57324132f5313.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 2, 12, 8, 1),
(45, 44, 'آگهی تست 36', 'توضیحات آگهی تست 36', '2000', 'no', '۱۳۹۷/۰۴/۳۱', 1, 2, 12, 12, 1),
(46, 44, 'آگهی تست 37', 'توضیحات آگهی تست 37', 'توافقی', '3f9007ab3c661bfb72cb9e01f41b3714.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 2, 14, 26, 1),
(47, 44, 'آگهی تست 38', 'توضیحات آگهی تست 38', 'توافقی', 'no', '۱۳۹۷/۰۴/۳۱', 1, 2, 15, 21, 1),
(48, 44, 'شلف های ام دی اف زیبا', 'هایپری\r\nخیلی زیبا\r\nتماس بگیرید\r\nارسال', 'توافقی', 'af00d84e9f925382890313bf7ae245ea.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 25, 1),
(49, 44, 'کمپرسور های کولر نو و استوک هیوندا کیا تویوتا ...', 'واردات و پخش کمپرسور کولر های هیوندا و کیا و تویوتاو مزدا و نیسان و.......\r\nپرداخت در تهران پس از دریافت جنس \r\nتلفن......02133923219......02133903894\r\nهمراه ..09126147497....09120727861', 'توافقی', '680dff190905dfc7abf0dd0ae0d4d448.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 8, 14, 1),
(50, 44, 'پارسtu5 کلاس 15 صفر - نقدی/ سری جدید', 'فروش محصولات ایران خودرو کدرسمی : 510988\r\n◧عرضه مستقیم خودرو پارسtu5 کلاس 15 کارتکس از پارکینگ نمایندگی\r\n◧در رنگ های مختلف\r\n◧تحویل فوری\r\n◧بدون کارمزد و هرگونه هزینه اضافی دیگر\r\n◧سند و پلاک بنام خریدار \r\n◧ترخیص خودرو از پارکینگ نمایندگی بنام خریدار\r\n◧2سال گارانتی پس از فروش\r\n◧1سال بیمه نامه شخص ثالث\r\n◧تخفیف بیمه بدنه\r\nتلفن های تماس نمایندگی:\r\n021-66916972 ***021-66421165', 'توافقی', 'c3e025d8cd9cc662abc0b75aca73a689.jpeg|8555b9128d24cc6d889a6ca59e2e9ce4.jpeg|9b68fd87d5e0978f9bae6b866180dcf2.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 5, 12, 1),
(51, 44, 'برلیانس230 دنده ای سری جدید-شرایطی', 'نمایندگی سایپا 510988\r\nبرلیانس 230 دنده ای شرایطی -چکی \r\n***********تحویل فوری**************\r\n✅پیش پرداخت متغیر\r\n✅بازپرداخت اقساط 1 ساله و 2ساله و 3ساله\r\n✅شرایط متنوع\r\n✅در رنگ بندی های مختلف\r\n✅بدون نیاز به ضامن\r\n✅چک کلیه بانک ها (حتی چک شهرستان) مورد قبول می باشد .\r\n✅امکان تسویه زودتر از موعد\r\n***********************************\r\nموتور 1600 4سیلندر خطی - بدنه سوپر سالن -16 سوپاپ \r\nرینگ آلومینیومی - صندوق جادار \r\n2 ایربگ - سیستم ضد سرقت موتور(ایموبلایزر ای سی یو) \r\nهشدار دهنده بسته نبودن کمربند ایمنی \r\nصندلی عقب با قابلیت پشتیبانی ایزوفیکس (صندلی کودک) \r\nقفل شیشه محافظ کودک \r\nکامپیوتر اطلاعات سفر\r\n***********************************\r\nمدارک مورد نیاز\r\nفقط کپی کارت ملی و شناسنامه\r\nاصل چک ها\r\n\r\nجهت اطلاع از شرایط \r\n66438510\r\n66429925\r\n66561975\r\n', 'توافقی', '31df66d7f0de0c5e947a17ab179aeb2e.jpeg|3b6311fca095b2980f698bcf6ae7ed40.jpeg|2abc2de0b9972a63871c6d745f528b13.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 1, 12, 3),
(52, 44, 'Cartier', 'ساعت کارتییر زنانه\r\nنو\r\nفقط فروش', '75000', 'ebd6ae04191ddc3c02bb910fba0519c0.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 3, 21, 2),
(53, 44, 'قفسه اهنی', 'قفسه اهنی\r\nسایز ٢*٢\r\nاستفاده برای تمامی مشاغل\r\nبازدید یا خرید از ساعت ٧ صبح الی ٢ بعدظهر', '350000', '99956e58428b49289c901afa47635238.jpeg', '۱۳۹۷/۰۴/۳۱', 1, 1, 3, 25, 2),
(54, 44, 'لل', 'ییی', '55', 'no', '۱۳۹۷/۰۵/۰۳', 0, 1, 1, 6, 0),
(55, 12, 'ddd', 'توضیحات', 'توافقی', 'f4c807cc5608ed282c5a93144d65be22.jpeg', '۱۳۹۷/۰۵/۱۰', 1, 1, 95, 6, 1),
(56, 12, 'آگهی 2', 'توضیحات 2', '90000', '431b56a4186f1bc9d5a32e386b724f87.jpeg|c1f5a4a4368ec710ad3bd11a648a99a7.jpeg', '۱۳۹۷/۰۵/۱۰', 0, 1, 2, 13, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL,
  `onvan` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `tozihat` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `parent` varchar(255) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `onvan`, `tozihat`, `parent`) VALUES
(1, 'املاک', '', 'y'),
(2, 'وسایل نقلیه', '', 'y'),
(3, 'استخدام و کاریابی', '', 'y'),
(4, 'وسایل شخصی', '', 'y'),
(5, 'کسب و کار', '', 'y'),
(6, 'خدمات املاک', '', '1'),
(7, 'فروش مسکونی', '', '1'),
(8, 'اجاره مسکونی', '', '1'),
(9, 'فروش اداری و تجاری', '', '1'),
(10, 'اجاره اداری و تجاری', '', '1'),
(11, 'قایق و لوازم جانبی', '', '2'),
(12, 'خودرو', '', '2'),
(13, 'کامیون', '', '2'),
(14, 'قطعات یدکی و لوازم جانبی خودرو', '', '2'),
(15, 'موتور سیکلت و لوازم جانبی', '', '2'),
(16, 'اداری و مدیریت', '', '3'),
(17, 'سرایداری و نظافت', '', '3'),
(18, 'معماری ، عمران و ساختمان', '', '3'),
(19, 'خدمات فروشگاه و رستوران', '', '3'),
(20, 'کیف و کفش ولباس', '', '4'),
(21, 'تزئینی', '', '4'),
(22, 'آرایشی ، بهداشتی و درمانی', '', '4'),
(23, 'کفش و لباس بچه', '', '4'),
(24, 'وسایل بچه و اسباب بازی', '', '4'),
(25, 'تجهیزات و ماشین آلات', '', '5'),
(26, 'عمده فروشی', '', '5');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_city`
--

CREATE TABLE `tbl_city` (
  `id` int(11) NOT NULL,
  `latin_name` varchar(150) COLLATE utf8_persian_ci NOT NULL,
  `persian_name` varchar(150) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tbl_city`
--

INSERT INTO `tbl_city` (`id`, `latin_name`, `persian_name`) VALUES
(1, 'tehran', 'تهران'),
(2, 'mashhad', 'مشهد'),
(3, 'esfahan', 'اصفهان'),
(4, 'tabriz', 'تبریز'),
(5, 'kish', 'کیش'),
(6, 'kerman', 'کرمان'),
(7, 'yazd', 'یزد'),
(8, 'yasouj', 'یاسوج'),
(9, 'birjand', 'بیرجند'),
(10, 'semnan', 'سمنان'),
(11, 'bandar', 'بندرعباس'),
(12, 'ahvaz', 'اهواز'),
(13, 'ilam', 'ایلام'),
(14, 'kermanshah', 'کرمانشاه'),
(15, 'zahedan', 'زاهدان'),
(19, 'shiraz', 'شیراز');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mahale`
--

CREATE TABLE `tbl_mahale` (
  `id` int(11) NOT NULL,
  `city_id` int(255) NOT NULL DEFAULT '1',
  `name` varchar(150) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tbl_mahale`
--

INSERT INTO `tbl_mahale` (`id`, `city_id`, `name`) VALUES
(1, 1, 'ابراهیم آباد'),
(2, 1, 'ابوذر'),
(3, 1, 'احتشامیه'),
(5, 1, 'ایرانشهر'),
(6, 1, 'آجودانیه'),
(7, 1, 'آذربایجان'),
(8, 1, 'آذری'),
(9, 1, 'آرارات'),
(10, 1, 'آرژانتین'),
(11, 2, '17 شهریور'),
(12, 2, 'آزاد شهر'),
(13, 2, 'ابوطالب'),
(14, 2, 'احمد آباد'),
(15, 2, 'امام خمینی'),
(16, 2, 'امام رضا(ع)'),
(17, 2, 'امامت'),
(18, 2, 'اندیشه'),
(19, 2, 'یلوار الهیه'),
(20, 3, 'آتشگاه'),
(21, 3, 'ابن سینا'),
(22, 3, 'بزرگمهر'),
(23, 3, 'بهارستان'),
(24, 3, 'بید اباد'),
(25, 3, 'پروین'),
(26, 3, 'پل شیری'),
(27, 3, 'پل وحید'),
(28, 19, 'ادبیات'),
(29, 19, 'ارتش'),
(30, 19, 'ارم'),
(31, 19, 'اطلسی'),
(32, 19, 'امیرکبیر'),
(33, 19, 'باهنر جنوبی'),
(34, 19, 'باهنر شمالی'),
(35, 19, 'بعثت'),
(36, 19, 'بلوار رحمت'),
(87, 1, 'استاد معین'),
(88, 1, 'استخر'),
(89, 1, 'اسفندیاری'),
(90, 1, 'اسکندری'),
(91, 1, 'اسلام آباد'),
(92, 1, 'افسریه'),
(93, 1, 'اقدسیه'),
(94, 1, 'اکباتان'),
(95, 1, 'المهدی'),
(96, 1, 'الهیه'),
(97, 1, 'امام حسین(ع)'),
(98, 1, 'امام زاده قاسم'),
(99, 1, 'امانیه'),
(100, 1, 'امیربهادر'),
(101, 1, 'امیرآباد'),
(102, 1, 'امیریه');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_report`
--

CREATE TABLE `tbl_report` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tbl_report`
--

INSERT INTO `tbl_report` (`id`, `name`) VALUES
(1, 'محتوای آگهی نامناسب می باشد'),
(2, 'اطلاعات آگهی نادرست می باشد');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reports`
--

CREATE TABLE `tbl_reports` (
  `id` int(11) NOT NULL,
  `report_id` int(255) NOT NULL,
  `agahi_id` int(255) NOT NULL,
  `ip` varchar(200) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tbl_reports`
--

INSERT INTO `tbl_reports` (`id`, `report_id`, `agahi_id`, `ip`) VALUES
(21, 1, 22, '::1'),
(22, 2, 23, '::1'),
(23, 1, 25, '::1'),
(26, 1, 27, '::1'),
(37, 2, 27, '::1'),
(41, 2, 24, '::1'),
(42, 2, 25, '::1'),
(49, 2, 36, '::1'),
(50, 2, 2, '::1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_site`
--

CREATE TABLE `tbl_site` (
  `id` int(11) NOT NULL DEFAULT '1',
  `title` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_persian_ci,
  `about` text COLLATE utf8mb4_persian_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `tbl_site`
--

INSERT INTO `tbl_site` (`id`, `title`, `description`, `about`) VALUES
(1, NULL, NULL, '<p><span style=\"color: rgb(26, 188, 156);\">پروژه کارشناسی رشته کامپیوتر تحت عنوان &laquo;نیازمندی های آنلاین&raquo; در &nbsp;سال 1397 توسط دانشجو ایوب سابقی نژاد ایجاد شده است.</span></p><h1>نیازمندی&zwnj;های ریز و درشت شما در &laquo;نیازمندی های آنلاین&raquo;</h1><p>شما به آسانی می&zwnj;توانید نیازمندی&zwnj;هایتان را بر اساس محله دسته&zwnj;بندی کنید و نزدیک&zwnj;ترین&zwnj;ها را بیابید.</p><p>&nbsp;</p><h2>برای قرار دادنِ آگهی&zwnj;های خود</h2><p>شهرتان را مشخص نمایید، روی ورود کلیک کنید و در پنل مدیریت آگهی خود را ایجاد کنید و &nbsp;آگهی&zwnj;تان در معرض دید عموم قرار دهید.</p><p>فراموش نکنید پیش از هر چیز یک آدرس ایمیل و یک شماره تلفن برای ارسال آگهی ضروری است. شما می&zwnj;توانید برای کالا یا خدمات&zwnj;تان عکسی نیز انتخاب کنید.</p><p>به این ترتیب میلیون&zwnj;ها کاربر به آسانی آگهی&zwnj; شما را خواهند دید و بر اساس محل آگهی شما را راحت&zwnj;تر خواهند یافت.</p><p>&nbsp;</p><h2>خرید و فروش بی&zwnj;واسطه</h2><p>در سایت &laquo;نیازمندی های آنلاین&raquo; کاربران مستقیماً با هم تماس می&zwnj;گیرند و هیچ واسطه&zwnj;ای در این میان وجود ندارد، پس دقت فرمایید که در خرید و فروشِ شما هیچ دخالتی وجود ندارد و کاربران باید خودشان جنبه&zwnj;های مختلف امنیتی را در نظر بگیرند.</p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p>ما را در شبکه های اجتماعی دنبال کنید:</p><p><br></p><p><br></p><div class=\"about-sn\"><p align=\"center\"><a href=\"http://www.facebook.com\"><img src=\"http://localhost/web/uploads/froala_images/3572313bde783da2f2fabfd76d1eba317d05f56e.png\" style=\"width: 64px;\" class=\"fr-fic fr-dib\"></a> <a href=\"http://twitter.com\"><img src=\"http://localhost/web/uploads/froala_images/da339c332b58ece41a7781925fe90cf1530262cf.png\" style=\"width: 64px;\" class=\"fr-fic fr-dib\"></a> <a href=\"http://www.t.me/a77mp\"></a><a href=\"http://www.instagram.com\"><img src=\"http://localhost/web/uploads/froala_images/da773cbda8ec9883cc0c8063e3690703bc9de0cd.png\" style=\"width: 64px;\" class=\"fr-fic fr-dib\"></a><span style=\"color: rgb(255, 255, 255);\">&nbsp;</span><a href=\"http://t.me/a77mp\" rel=\"noopener noreferrer\" target=\"_blank\"><img src=\"http://localhost/web/uploads/froala_images/6b5321f5b62527a56e4bb0d8f65a99b4a4a5cf6f.png\" style=\"width: 64px;\" class=\"fr-fic fr-dib\"></a>&nbsp; &nbsp;</p></div><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p>&nbsp;</p><p>&nbsp;</p><p><a href=\"http://cafebazaar.ir/app/ir.divar/?l=fa\" target=\"_blank\"></a> <a href=\"https://itunes.apple.com/us/app/id863029557\" target=\"_blank\"></a></p><p style=\"text-align: center;\">&copy;2018 | کلیه حقوق محفوظ است.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `name` varchar(120) COLLATE utf8_persian_ci NOT NULL,
  `family` varchar(120) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(180) COLLATE utf8_persian_ci NOT NULL,
  `tel` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(500) CHARACTER SET utf8 NOT NULL,
  `enum` varchar(150) COLLATE utf8_persian_ci NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `name`, `family`, `email`, `tel`, `password`, `enum`) VALUES
(12, 'ahmad', 'rezaaaaeii', 'ww@ff.c', '2225', '$2y$13$r5yz4t6k5p6cugeNbfzRZO5bKkjVWpDaOGlLn4iG7HLz/UI7NmRde', 'user'),
(13, 'farid', 'ss', 'saead@mai.v', '222', '$2y$13$eCzJOtCNMHzOyWaoUd.PEu2mNe.JfE2RT7hUwiUtfdNGm0MpubVHS', ''),
(14, 'ali', 'rahmani', 'a@r.c', '555', '$2y$13$eth.bmPZ08XEv7XOrrq4AuWMDg32ytRkbsJUyeEyk1zi9W54NINGq', ''),
(15, 'farshad', 'sss', 'farshad@s.c', '55533', '$2y$13$jbl/d9Mxv6tlDSjMfhu86.mIegWq8LCVC/clyTQeQLiuwKCchQYha', 'user'),
(16, 'aa', 'qq', 'qq@d.x', '222', '$2y$13$cH51naRma1QyYaaTidHKUO1rvBruJ38oiv1OF/eiNCzFkhNwFPwNq', ''),
(18, 'ahmad', 'saeidi', 'a@s.c', '333', '$2y$13$T.uIjDV9h56eeRB6dFlnCuSXLVZsJm7joBrMSNU48UY7OZkBaQMpu', ''),
(23, 'ttt', 'www', 'ee@ee.gg', '441', '$2y$13$6SoaeZaq0FWQwdhFZCL9IObBbxt88m3jJSNrHqpFRalaOUwZpF0Pi', ''),
(24, 'dddss', 'sss', 'hh@jj.cc', '222', '$2y$13$nUtFp.yyVnsct5MvbGAdKuHr1up0rNcs4Ioy1Xhwyg5jzS1koM/ya', ''),
(26, 'sss', 'wws', 'ddd@dd.jg', '221', '$2y$13$2XBETA7VStvHDW1DQJeW9ekadgvImS5eQ5tqAd.MOibyBJMI0AGhO', ''),
(31, 'hhh', 'erer', 'ww@yy.v', '3434', '$2y$13$RU.56kkATmfd.aWtQSzVzO.BBSkhHxPV7wAtOTva5h2lr3b4acbTq', ''),
(32, 'مهدی', 'صبوری', 'm@s.gg', '0911333555', '$2y$13$NAKCYRG1s.f3FHAM4mjLU.nhdV16mJeBs2wkCNUcrqIG8RL2giy3y', ''),
(33, 'ali', 'asdasd', 'ali@s.c', '091133333333', '$2y$13$VJ85Iz1CnO0cQjhtvRzYBeaMMjFTInzb2ahKlcK7CvY2r77Zq7BxC', ''),
(34, 'shahram', 'sadeghi', 's@sa.c', '666', '$2y$13$DCszMKuSQJwcUo4HoRwHTOPGSWE6xtbUgZH2N02c.L401z1c/H1H6', ''),
(35, 'ccc', 'yyy', 'ii@ff.ll', '6667', '$2y$13$tjvH/qJUOPgG.J1mGYmDdeZKFDb.dIxx5DKTeLpP3BrCoCrRkjnnu', 'admin'),
(36, 'فرهاد', 'یی', 'ff@h.b', '3988', '$2y$13$hpJZk6KYUBBeNgH96.MiV.KlDZWB7K9AtLXrmrycs29eaSf2F02fe', 'user'),
(37, 'مهدی', 'مجیدی', 'mehdimag@mm.c', '12345', '$2y$13$sOw5rs4gV8J0/MGs83lfeuuPgOuwzPNUSUK0Zh13uJCSNmTk8y8su', 'admin'),
(38, 'ali', 'dddd', 'add@ss.h', '123', '$2y$13$y/TCOAJlHMl2F./FwIZIj.Zh5rP8AUc8OgvIMr46GMHia2z8eedc2', 'user'),
(39, 'ali', 'farhadi', 'af@ss.c', '55', '$2y$13$iE.DD8h/xGJt121VHaUWT.MY8uYHXNTW600XuefiS2OjruvQY3H0G', 'admin'),
(40, 'hh', 'kk', 'll@l.n', '44', '$2y$13$h1ClAruMF3pCDuZPpxsDlejR7TePSK5hxaUvyi.51okLEDYZQJPbK', 'user'),
(41, 'oo', 'pp', 'oo@pp.k', '888', '$2y$13$y3lCeuq8Yp6iaa3cH9O8a.Ir8.afp7t7TFcUM55xaUqIsQNDcGAPi', 'admin'),
(42, 'ii', 'ppp', 'af@ss.cp', '366', '$2y$13$vDsx79PiafUX46Nvl1hQR.bqpFKD9WEfQLxKoEAVVHhZzFfjNpc4O', 'admin'),
(43, 'ali', 'ssss', 'ddd@ee.ll', '456', '$2y$13$1qOIJlG3rlVapH2sluIyQeWFULmox9vE7LILgaavA72S08SqsNJM6', 'user'),
(44, 'ایوب', 'سابقی نژاد', 'a.sabeghi77@gmail.com', '09162430364', '$2y$13$zbBhJeakMEXQl9NbOx9r0O4biUwhSmvghVTkRquZXAOmWpoM97EZa', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_agahi`
--
ALTER TABLE `tbl_agahi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `city_id` (`city_id`),
  ADD KEY `cat_id` (`cat_id`),
  ADD KEY `mahale_id` (`mahale_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_city`
--
ALTER TABLE `tbl_city`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `latin_name` (`latin_name`),
  ADD UNIQUE KEY `persian_name` (`persian_name`);

--
-- Indexes for table `tbl_mahale`
--
ALTER TABLE `tbl_mahale`
  ADD PRIMARY KEY (`id`),
  ADD KEY `city_id` (`city_id`);

--
-- Indexes for table `tbl_report`
--
ALTER TABLE `tbl_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reports`
--
ALTER TABLE `tbl_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `report_id` (`report_id`),
  ADD KEY `agahi_id` (`agahi_id`);

--
-- Indexes for table `tbl_site`
--
ALTER TABLE `tbl_site`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_agahi`
--
ALTER TABLE `tbl_agahi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tbl_city`
--
ALTER TABLE `tbl_city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_mahale`
--
ALTER TABLE `tbl_mahale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `tbl_report`
--
ALTER TABLE `tbl_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_reports`
--
ALTER TABLE `tbl_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_agahi`
--
ALTER TABLE `tbl_agahi`
  ADD CONSTRAINT `tbl_agahi_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_agahi_ibfk_2` FOREIGN KEY (`cat_id`) REFERENCES `tbl_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_agahi_ibfk_3` FOREIGN KEY (`mahale_id`) REFERENCES `tbl_mahale` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_agahi_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_mahale`
--
ALTER TABLE `tbl_mahale`
  ADD CONSTRAINT `tbl_mahale_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `tbl_city` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_reports`
--
ALTER TABLE `tbl_reports`
  ADD CONSTRAINT `tbl_reports_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `tbl_report` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_reports_ibfk_2` FOREIGN KEY (`agahi_id`) REFERENCES `tbl_agahi` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
